<div class="header">
		<a href="index.php">Главная</a>
		<a href="puzzle.php">Загадки</a>
		<a href="guess.php">Угадай число</a>
		<a href="generate_password.php">Генератор паролей</a>
</div>



